# Perbaikan terbaru (4 Nov 2026)

## frontend → GitHub (14 berkas)
Seret isi folder `frontend` ke Codespace (akar repo `portal`), timpa berkas yang namanya sama. Lalu ketik satu per satu:
`git add -A`
`git commit -m "perbaikan"`
`git push`
Tunggu 1–2 menit, buka portal, tekan Ctrl+Shift+R.

## backend → Apps Script (8 berkas di 2 proyek)
Folder `backend/PORTAL` (7 berkas) → tempel di proyek **PORTAL RELAWAN**.
Folder `backend/SIPENDOK` (1 berkas: SipanduPmHarian) → tempel di proyek **SIPENDOK**.
Cara: buka berkas bernama sama di editor Apps Script, Ctrl+A, tempel isi berkas dari zip, Ctrl+S.
Setelah itu di KEDUA proyek: Deploy → Manage deployments → pensil → New version → Deploy. Tidak ada fungsi yang dijalankan.
SIPOGIM dan database: tidak ada yang berubah.
(Opsional: salin berkas backend itu juga ke folder `backend/portal` dan `backend/sipendok` di repo agar GitHub sama dengan Apps Script.)

## Aturan baru yang ikut di zip ini
Instansi NONAKTIF dianggap 0 di semua yang bersumber dari PM Harian: Manajemen PM, kalender, dashboard, website, Pagu, Rekap Biaya, Insentif PIC, dokumen dan pagu SIPENDOK. Data lamanya tidak hilang; mengaktifkan instansi memunculkannya lagi.
