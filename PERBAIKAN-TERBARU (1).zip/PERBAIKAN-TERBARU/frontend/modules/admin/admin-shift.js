// ============================================================
// SPPG JEUNGJING — MODUL SHIFT & KOREKSI (Dashboard Admin)
// File BARU, terpisah dari admin.js. Memakai window.sppgAdminToken
// (hook yang sama dipakai admin-stok.js) dan fungsi bersama common.js.
// ============================================================

(function () {
  'use strict';

  const el = {
    tabBtn: document.querySelector('.admin-tab-btn[data-panel="panelShift"]'),
    subtabs: document.querySelectorAll('.shift-subtab'),
    subs: document.querySelectorAll('.shift-sub'),



    formPenugasanKhusus: document.getElementById('formPenugasanKhusus'),
    khususOperasional: document.getElementById('khususOperasional'),
    khususPilihPeriode: document.getElementById('khususPilihPeriode'), // BARU 24 Okt 2026
    khususPeriode: document.getElementById('khususPeriode'),
    khususMingguKeterangan: document.getElementById('khususMingguKeterangan'),
    khususModeTanggalHari: document.getElementById('khususModeTanggalHari'),
    khususModeTanggalPeriode: document.getElementById('khususModeTanggalPeriode'),
    khususRelawan: document.getElementById('khususRelawan'),
    khususDivisi: document.getElementById('khususDivisi'),
    khususModeRelawanIndividu: document.getElementById('khususModeRelawanIndividu'),
    khususModeRelawanDivisi: document.getElementById('khususModeRelawanDivisi'),
    khususJamMasuk: document.getElementById('khususJamMasuk'),
    khususJamPulang: document.getElementById('khususJamPulang'),
    khususCatatan: document.getElementById('khususCatatan'),
    tbodyPenugasanKhusus: document.getElementById('tbodyPenugasanKhusus'),

    koreksiRelawan: document.getElementById('koreksiRelawan'),
    koreksiTanggalPresensi: document.getElementById('koreksiTanggalPresensi'),
    btnCariKoreksi: document.getElementById('btnCariKoreksi'),
    koreksiHasil: document.getElementById('koreksiHasil')
  };

  if (!el.tabBtn) return;

  const cache = { periode: [], kalender: [], relawan: [], divisi: [] };
  let sudahInit = false;

  function token() { return window.sppgAdminToken; }

  // --------------------------------------------------------
  // SUB-TAB
  // --------------------------------------------------------
  el.subtabs.forEach(btn => {
    btn.addEventListener('click', () => {
      el.subtabs.forEach(b => b.classList.remove('active'));
      el.subs.forEach(s => { s.style.display = 'none'; });
      btn.classList.add('active');
      const target = document.getElementById('shiftSub' + btn.dataset.sub.charAt(0).toUpperCase() + btn.dataset.sub.slice(1));
      if (target) target.style.display = 'block';
    });
  });
  el.subtabs[0].classList.add('active');

  window.addEventListener('sppg-admin-ready', () => { if (!sudahInit) { sudahInit = true; initShift(); } });
  if (window.sppgAdminToken && !sudahInit) { sudahInit = true; initShift(); }

  async function initShift() {
    try {
      const [periode, divisi, relawan, kalender] = await Promise.all([
        apiGet('getPeriodeListAdmin', { token: token() }),
        apiGetCached('getDivisi', { token: token() }, 600000),
        apiGet('getRelawan', { semua: 1, token: token() }),
        apiGet('getKalenderListAdmin', { token: token() })
      ]);
      cache.periode = periode;
      cache.divisi = divisi;
      cache.relawan = relawan;
      cache.kalender = kalender;

      el.khususRelawan.innerHTML = '<option value="">Pilih Relawan...</option>' +
        relawan.map(r => `<option value="${escapeHtml(r.id)}">${escapeHtml(r.nama)}</option>`).join('');
      el.khususDivisi.innerHTML = '<option value="">Pilih Divisi...</option>' +
        divisi.map(d => `<option value="${escapeHtml(d)}">${escapeHtml(d)}</option>`).join('');
      // Multi-Shift (18 Okt 2026, SIKOP) -- pakai ulang data periode/divisi/relawan yg SAMA, tidak ada panggilan API baru.
      // Diperbaiki 22 Okt 2026: label diubah jadi "opsional" krn Pola
      // Kerja/Kelompok Rotasi sudah tidak butuh periode lagi.
      document.getElementById('msPeriode').innerHTML = '<option value="">(Opsional, utk Override Per Tanggal)</option>' +
        periode.map(p => `<option value="${escapeHtml(p.id)}">${escapeHtml(p.nama)}</option>`).join('');
      document.getElementById('msDivisi').innerHTML = '<option value="">Pilih Divisi...</option>' +
        divisi.map(d => `<option value="${escapeHtml(d)}">${escapeHtml(d)}</option>`).join('');
      document.getElementById('krRelawan').innerHTML = '<option value="">Pilih Relawan...</option>' +
        relawan.map(r => `<option value="${escapeHtml(r.id)}">${escapeHtml(r.nama)}</option>`).join('');
      // Pemeriksaan Jadwal & Penetapan Jadwal (2 halaman terpisah, sesuai
      // wireframe) -- dropdown periode, pakai ulang data yg sama.
      document.getElementById('pmrPeriode').innerHTML = '<option value="">Pilih Periode...</option>' +
        periode.map(p => `<option value="${escapeHtml(p.id)}">${escapeHtml(p.nama)}</option>`).join('');
      document.getElementById('ptpPeriode').innerHTML = '<option value="">Pilih Periode...</option>' +
        periode.map(p => `<option value="${escapeHtml(p.id)}">${escapeHtml(p.nama)}</option>`).join('');
      // Pembuatan Jadwal -- Periode BARU 24 Okt 2026 (opsional, lihat
      // catatan lengkap di admin.html dekat #pbjPeriode).
      document.getElementById('pbjPeriode').innerHTML = '<option value="">(Semua periode aktif)</option>' +
        periode.map(p => `<option value="${escapeHtml(p.id)}">${escapeHtml(p.nama)}</option>`).join('');
      // BARU 24 Okt 2026 -- dropdown Periode di Penugasan Khusus (mode Satu Minggu).
      el.khususPilihPeriode.innerHTML = '<option value="">(Pilih periode utk isi tanggal otomatis...)</option>' +
        periode.map(p => `<option value="${escapeHtml(p.id)}">${escapeHtml(p.nama)}</option>`).join('');
      document.getElementById('pbjDivisiCheckbox').innerHTML = divisi.map(d => `
        <label style="display:flex;align-items:center;gap:6px;font-size:13px;padding:6px 10px;border:1px solid var(--color-border);border-radius:8px;cursor:pointer;">
          <input type="checkbox" class="pbj-divisi-checkbox" value="${escapeHtml(d)}" style="width:16px;height:16px;"> ${escapeHtml(d)}
        </label>`).join('');
      // PERUBAHAN: khususPeriode sekarang <input type="date"> (pilih 1 minggu,
      // bukan lagi dropdown Periode) -- tidak perlu diisi dari daftar periode lagi.
      el.koreksiRelawan.innerHTML = '<option value="">Pilih Relawan...</option>' +
        relawan.map(r => `<option value="${escapeHtml(r.id)}">${escapeHtml(r.nama)}</option>`).join('');
      el.khususOperasional.innerHTML = '<option value="">Pilih Tanggal Operasional...</option>' +
        kalender.map(k => `<option value="${escapeHtml(k.id)}">${escapeHtml(k.tanggal)} (${escapeHtml(k.namaPeriode)})</option>`).join('');
    } catch (err) {
      // diam-diam di init awal, pesan error akan muncul saat user benar-benar interaksi
    }
  }

  // --------------------------------------------------------
  // PENUGASAN KHUSUS -- TOGGLE MODE (Satu Hari/Periode, Individu/Divisi)
  // --------------------------------------------------------
  let modeTanggal = 'hari';   // 'hari' | 'periode'
  let modeRelawan = 'individu'; // 'individu' | 'divisi'

  el.khususModeTanggalHari.addEventListener('click', () => {
    modeTanggal = 'hari';
    el.khususModeTanggalHari.classList.add('primary');
    el.khususModeTanggalPeriode.classList.remove('primary');
    el.khususOperasional.style.display = '';
    el.khususPeriode.style.display = 'none';
    muatPenugasanKhusus();
  });
  el.khususModeTanggalPeriode.addEventListener('click', () => {
    modeTanggal = 'periode';
    el.khususModeTanggalPeriode.classList.add('primary');
    el.khususModeTanggalHari.classList.remove('primary');
    el.khususOperasional.style.display = 'none';
    el.khususPilihPeriode.style.display = ''; // BARU 24 Okt 2026
    el.khususPeriode.style.display = '';
    el.khususMingguKeterangan.style.display = '';
    el.tbodyPenugasanKhusus.innerHTML = '<tr><td colspan="5"><div class="empty-state">Daftar di bawah menampilkan penugasan per hari. Pilih "Satu Hari" untuk melihat daftarnya, atau lanjutkan di sini untuk membuat penugasan ke 1 minggu (7 hari) sekaligus.</div></td></tr>';
  });
  // BARU 24 Okt 2026 (diminta Admin) -- pilih Periode cukup isi
  // tanggal mulai (#khususPeriode) otomatis dari TANGGAL_MULAI periode
  // itu, lalu picu event 'change' yg SUDAH ADA (hitung "Mencakup: ...")
  // supaya tidak perlu duplikasi logika. Field tanggal TETAP bisa
  // diedit manual sesudahnya kalau Admin mau geser beberapa hari.
  let khususAkhirPeriodeDipilih = ''; // BARU 24 Okt 2026 -- tanggal selesai periode yg dipilih, dikirim ke backend spy cakupan 1 PERIODE PENUH (bukan dibatasi 7 hari), lihat Shift.gs
  const dmyKeIsoInline_ = (dmy) => { const b = String(dmy || '').split('/'); return b.length === 3 ? (b[2] + '-' + b[1].padStart(2, '0') + '-' + b[0].padStart(2, '0')) : ''; };
  el.khususPilihPeriode.addEventListener('change', () => {
    const p = (cache.periodeList || []).find(x => x.id === el.khususPilihPeriode.value);
    if (!p || !p.tanggalMulai) { khususAkhirPeriodeDipilih = ''; return; }
    el.khususPeriode.value = dmyKeIsoInline_(p.tanggalMulai);
    khususAkhirPeriodeDipilih = dmyKeIsoInline_(p.tanggalSelesai); // dikirim saat submit, lihat payload di bawah
    el.khususPeriode.dispatchEvent(new Event('change'));
  });
  // PERUBAHAN: dulu "Satu Periode Penuh" (bisa 2+ minggu sekaligus), sekarang
  // dibatasi 1 minggu (7 hari) dari tanggal yang dipilih -- supaya cakupan
  // bulk-assign tidak terlalu luas/berisiko secara tidak sengaja.
  el.khususPeriode.addEventListener('change', () => {
    if (!el.khususPeriode.value) { el.khususMingguKeterangan.textContent = ''; return; }
    const mulai = new Date(el.khususPeriode.value + 'T00:00:00');
    // BARU 24 Okt 2026 -- kalau Periode dipilih dari dropdown, teks
    // pratinjau ikut tampilkan cakupan PERIODE PENUH yg sesungguhnya
    // dikirim ke backend (bukan selalu "7 hari"), supaya tidak menyesatkan.
    const akhir = khususAkhirPeriodeDipilih ? new Date(khususAkhirPeriodeDipilih + 'T00:00:00') : new Date(mulai.getTime() + 6 * 86400000);
    const jumlahHari = Math.round((akhir.getTime() - mulai.getTime()) / 86400000) + 1;
    const fmt = (d) => d.toLocaleDateString('id-ID', { day: 'numeric', month: 'short', year: 'numeric' });
    el.khususMingguKeterangan.textContent = `Mencakup: ${fmt(mulai)} s/d ${fmt(akhir)} (${jumlahHari} hari)`;
  });
  el.khususModeRelawanIndividu.addEventListener('click', () => {
    modeRelawan = 'individu';
    el.khususModeRelawanIndividu.classList.add('primary');
    el.khususModeRelawanDivisi.classList.remove('primary');
    el.khususRelawan.style.display = '';
    el.khususDivisi.style.display = 'none';
  });
  el.khususModeRelawanDivisi.addEventListener('click', () => {
    modeRelawan = 'divisi';
    el.khususModeRelawanDivisi.classList.add('primary');
    el.khususModeRelawanIndividu.classList.remove('primary');
    el.khususRelawan.style.display = 'none';
    el.khususDivisi.style.display = '';
  });

  // Dihapus 22 Okt 2026 (diminta Admin): seksi JS "SHIFT DIVISI" --
  // HTML-nya sudah dihapus (fungsinya tercakup mode "Jam Tetap" di
  // Pengaturan > Pola Kerja per Divisi), jadi kode yg memanggil
  // elemen HTML itu (SEKARANG NULL) HARUS ikut dihapus -- kalau
  // dibiarkan, baris addEventListener di bawah akan error saat file
  // ini jalan dan mematikan SELURUH sisa script.

  // --------------------------------------------------------
  // PENUGASAN KHUSUS (sekarang bagian dari Pembuatan Jadwal, HTML-nya
  // dipindah 22 Okt 2026 -- ID elemen & logika di bawah TIDAK berubah)
  // --------------------------------------------------------
  el.khususOperasional.addEventListener('change', muatPenugasanKhusus);

  async function muatPenugasanKhusus() {
    const idOperasional = el.khususOperasional.value;
    if (!idOperasional) { el.tbodyPenugasanKhusus.innerHTML = '<tr><td colspan="5"><div class="empty-state">Pilih tanggal operasional di atas dulu.</div></td></tr>'; return; }
    el.tbodyPenugasanKhusus.innerHTML = '<tr><td colspan="5"><div class="empty-state">Memuat data...</div></td></tr>';
    try {
      const list = await apiGet('getPenugasanKhususListAdmin', { token: token(), idOperasional });
      if (!list.length) { el.tbodyPenugasanKhusus.innerHTML = '<tr><td colspan="5"><div class="empty-state">Belum ada penugasan khusus untuk tanggal ini.</div></td></tr>'; return; }
      el.tbodyPenugasanKhusus.innerHTML = list.map(p => `
        <tr>
          <td>${escapeHtml(p.namaRelawan)}</td>
          <td>${escapeHtml(p.jamMasuk)}</td>
          <td>${escapeHtml(p.jamPulang || '-')}</td>
          <td>${escapeHtml(p.catatan || '-')}</td>
          <td><button type="button" class="btn-mini" data-hapus-khusus="${escapeHtml(p.id)}">Hapus</button></td>
        </tr>`).join('');
      el.tbodyPenugasanKhusus.querySelectorAll('[data-hapus-khusus]').forEach(btn => {
        btn.addEventListener('click', async () => {
          try {
            await apiPost('deletePenugasanKhusus', { token: token(), id: btn.dataset.hapusKhusus });
            showSuccess('Penugasan khusus dihapus.');
            muatPenugasanKhusus();
          } catch (err) { showError(err.message); }
        });
      });
    } catch (err) {
      showError(err.message);
    }
  }

  el.formPenugasanKhusus.addEventListener('submit', async (e) => {
    e.preventDefault();

    const payload = {
      token: token(),
      jamMasuk: el.khususJamMasuk.value,
      jamPulang: el.khususJamPulang.value,
      catatan: el.khususCatatan.value.trim()
    };

    if (modeTanggal === 'periode') {
      if (!el.khususPeriode.value) { showError('Pilih tanggal mulai minggu dulu.'); return; }
      payload.tanggalMulaiMinggu = el.khususPeriode.value;
      // BARU 24 Okt 2026 -- kalau Admin pilih Periode dari dropdown
      // (bukan cuma isi tanggal manual), kirim tanggal akhir periode
      // supaya backend pakai cakupan 1 PERIODE PENUH, bukan dibatasi
      // 7 hari (lihat catatan lengkap di Shift.gs). Kosong = perilaku
      // lama (7 hari), tidak berubah.
      if (khususAkhirPeriodeDipilih) payload.tanggalAkhirMinggu = khususAkhirPeriodeDipilih;
    } else {
      if (!el.khususOperasional.value) { showError('Pilih Tanggal Operasional dulu.'); return; }
      payload.idOperasional = el.khususOperasional.value;
    }

    if (modeRelawan === 'divisi') {
      if (!el.khususDivisi.value) { showError('Pilih Divisi dulu.'); return; }
      payload.namaDivisi = el.khususDivisi.value;
    } else {
      if (!el.khususRelawan.value) { showError('Pilih Relawan dulu.'); return; }
      payload.idRelawan = el.khususRelawan.value;
    }

    // Konfirmasi kalau salah satu (atau keduanya) mode bulk aktif -- supaya
    // tidak ada yang tidak sengaja menugaskan seluruh divisi/periode.
    if (modeTanggal === 'periode' || modeRelawan === 'divisi') {
      const keterangan = [
        modeTanggal === 'periode' ? `1 minggu (7 hari) mulai ${el.khususPeriode.value}` : 'tanggal yang dipilih',
        modeRelawan === 'divisi' ? `seluruh relawan aktif di divisi "${el.khususDivisi.value}"` : 'relawan yang dipilih'
      ];
      if (!confirm(`Ini akan membuat/memperbarui penugasan khusus untuk ${keterangan[1]}, pada ${keterangan[0]}. Lanjutkan?`)) return;
    }

    try {
      const hasil = await apiPost('addPenugasanKhususBulk', payload);
      if (hasil.jumlah === 1) {
        showSuccess('Penugasan khusus tersimpan.');
      } else {
        showSuccess(`Penugasan khusus tersimpan untuk ${hasil.jumlah} kombinasi relawan/hari (${hasil.jumlahBaru} baru, ${hasil.jumlahDiperbarui} diperbarui).`);
      }
      el.khususJamMasuk.value = ''; el.khususJamPulang.value = ''; el.khususCatatan.value = '';
      if (modeTanggal === 'hari') muatPenugasanKhusus();
    } catch (err) {
      showError(err.message);
    }
  });

  // --------------------------------------------------------
  // KOREKSI TANGGAL OPERASIONAL
  // --------------------------------------------------------
  function keTanggalDMY_(inputDateValue) {
    // input[type=date] value = "yyyy-mm-dd" -> ubah ke "dd/MM/yyyy"
    if (!inputDateValue) return '';
    const [y, m, d] = inputDateValue.split('-');
    return d + '/' + m + '/' + y;
  }

  el.btnCariKoreksi.addEventListener('click', async () => {
    const idRelawan = el.koreksiRelawan.value;
    const tanggalPresensi = keTanggalDMY_(el.koreksiTanggalPresensi.value);
    if (!idRelawan || !tanggalPresensi) { showError('Pilih relawan dan tanggal presensi dulu.'); return; }

    el.koreksiHasil.innerHTML = '<div class="empty-state">Mencari...</div>';
    try {
      const hasil = await apiGet('cariAbsensiUntukKoreksi', { token: token(), idRelawan, tanggalPresensi });
      if (!hasil.length) { el.koreksiHasil.innerHTML = '<div class="empty-state">Tidak ada absensi ditemukan untuk relawan & tanggal ini.</div>'; return; }

      const opsiTujuan = '<option value="">Pilih tanggal operasional yang benar...</option>' +
        cache.kalender.map(k => `<option value="${escapeHtml(k.id)}">${escapeHtml(k.tanggal)} (${escapeHtml(k.namaPeriode)}) — ${escapeHtml(k.hari)}</option>`).join('');

      // PERBAIKAN: cariAbsensiUntukKoreksi (backend, desain roster-first --
      // satu baris = seluruh presensi 1 relawan utk 1 operasional) mengirim
      // field idAbsensi/jamMasuk/jamPulang/status -- BUKAN jenis/jam/
      // tanggalTercatatSaatIni yang dipakai kode lama ini. Akibatnya Jenis &
      // Jam selalu tampil kosong, DAN kedua tombol aksi tidak pernah
      // mengirim idAbsensi (padahal itu yang dicari backend) -- selalu
      // gagal "Data koreksi tidak lengkap." Diperbaiki memakai nama field
      // yang SUNGGUHAN dikembalikan backend.
      el.koreksiHasil.innerHTML = hasil.map((h, i) => `
        <div class="shift-koreksi-row">
          <div class="profile-identity-list">
            <div class="profile-identity-row"><span>Jam Masuk</span><span>${h.jamMasuk ? escapeHtml(h.jamMasuk) : '(belum absen masuk)'}</span></div>
            <div class="profile-identity-row"><span>Jam Pulang</span><span>${h.jamPulang ? escapeHtml(h.jamPulang) : '(belum absen pulang)'}</span></div>
            <div class="profile-identity-row"><span>Status</span><span>${escapeHtml(h.status || '-')}</span></div>
            <div class="profile-identity-row"><span>Tanggal Operasional Saat Ini</span><span>${escapeHtml(h.tanggalOperasionalSaatIni)}</span></div>
          </div>
          <select id="koreksiTujuan${i}">${opsiTujuan}</select>
          <div style="display:flex;gap:8px;flex-wrap:wrap;">
            <button type="button" class="btn-mini primary" style="margin-top:8px;" data-aksi-koreksi="${escapeHtml(h.idAbsensi)}" data-koreksi-tujuan-idx="${i}">Koreksi ke Tanggal Ini</button>
            ${!h.jamMasuk ? `<button type="button" class="btn-mini" style="margin-top:8px;color:#1a7a3c;" data-aksi-tandai-hadir="${escapeHtml(h.idAbsensi)}">✓ Tandai Hadir Manual</button>` : ''}
            <button type="button" class="btn-mini" style="margin-top:8px;color:#b23a3a;" data-aksi-hapus="${escapeHtml(h.idAbsensi)}">Hapus Baris Ini</button>
          </div>
        </div>`).join('');

      el.koreksiHasil.querySelectorAll('[data-aksi-tandai-hadir]').forEach(btn => {
        btn.addEventListener('click', async () => {
          // Keterangan WAJIB -- ini memengaruhi rekap penggajian (lihat
          // catatan di tandaiHadirManual, Shift.gs), harus ada jejak audit.
          const keterangan = prompt('Alasan relawan ditandai Hadir manual (wajib diisi, akan tercatat untuk audit & memengaruhi rekap penggajian):');
          if (keterangan === null) return; // batal
          if (!keterangan.trim()) { showError('Alasan wajib diisi.'); return; }
          if (!confirm('Tandai relawan ini Hadir untuk tanggal operasional ini? Jam Masuk/Pulang akan diisi sesuai jadwal shift-nya.')) return;
          try {
            const hasilTandai = await apiPost('tandaiHadirManual', { token: token(), idAbsensi: btn.dataset.aksiTandaiHadir, keterangan: keterangan.trim() });
            showSuccess('Berhasil ditandai Hadir untuk operasional ' + hasilTandai.tanggalOperasional + '.');
            el.btnCariKoreksi.click();
          } catch (err) {
            showError(err.message);
          }
        });
      });

      el.koreksiHasil.querySelectorAll('[data-aksi-koreksi]').forEach(btn => {
        btn.addEventListener('click', async () => {
          const idOperasionalBaru = document.getElementById('koreksiTujuan' + btn.dataset.koreksiTujuanIdx).value;
          if (!idOperasionalBaru) { showError('Pilih tanggal operasional tujuan dulu.'); return; }
          if (!confirm('Yakin pindahkan baris absensi ini ke tanggal operasional yang dipilih? Jam/timestamp asli tidak berubah.')) return;
          try {
            const hasilKoreksi = await apiPost('koreksiTanggalOperasionalAbsensi', {
              token: token(), idAbsensi: btn.dataset.aksiKoreksi, idOperasionalBaru
            });
            showSuccess('Berhasil dikoreksi ke ' + hasilKoreksi.tanggalBaru + '.');
            el.btnCariKoreksi.click();
          } catch (err) {
            showError(err.message);
          }
        });
      });

      el.koreksiHasil.querySelectorAll('[data-aksi-hapus]').forEach(btn => {
        btn.addEventListener('click', async () => {
          // PERINGATAN GANDA (bukan cuma 1 confirm) -- ini penghapusan
          // permanen, dipakai antara lain untuk membuang data test yang
          // menempati slot operasional relawan asli (lihat error "Anda
          // sudah melakukan absensi masuk pada operasional ini.").
          if (!confirm('HAPUS PERMANEN baris absensi ini? Tindakan ini tidak bisa dibatalkan.')) return;
          if (!confirm('Konfirmasi sekali lagi: baris ini akan hilang selamanya dari 03_DATA_ABSENSI. Lanjutkan?')) return;
          try {
            await apiPost('hapusAbsensi', { token: token(), idAbsensi: btn.dataset.aksiHapus });
            showSuccess('Baris absensi berhasil dihapus.');
            el.btnCariKoreksi.click();
          } catch (err) {
            showError(err.message);
          }
        });
      });
    } catch (err) {
      el.koreksiHasil.innerHTML = '';
      showError(err.message);
    }
  });


  // ============================================================
  // MULTI-SHIFT (18 Okt 2026, SIKOP) -- Security/Pengolahan/Persiapan
  // ============================================================
  const msPeriodeEl = document.getElementById('msPeriode');
  const msDivisiEl = document.getElementById('msDivisi');
  const msIsiEl = document.getElementById('msIsi');

  // Diperbaiki 22 Okt 2026 (diminta Admin -- bug desain nyata): Pola
  // Kerja & Kelompok Rotasi sekarang STANDING per divisi, BUKAN per
  // periode -- jadi cukup pilih DIVISI utk memuatnya. Periode jadi
  // OPSIONAL, cuma dipakai menyaring daftar Override Per Tanggal yg
  // ditampilkan (Override GENUINELY terikat tanggal/periode tertentu).
  async function muatMultiShift_() {
    const namaDivisi = msDivisiEl.value;
    if (!namaDivisi) { msIsiEl.style.display = 'none'; return; }
    msIsiEl.style.display = 'block';
    try {
      const cfg = await apiPost('getKonfigurasiMultiShiftDivisi', { token: token(), idPeriode: msPeriodeEl.value || undefined, namaDivisi });
      renderMsDetail_(cfg.detail);
      renderMsKelompok_(cfg.kelompok);
      renderMsOverride_(cfg.override);
    } catch (err) {
      showError(err.message || 'Gagal memuat konfigurasi multi-shift.');
    }
  }
  msPeriodeEl.addEventListener('change', muatMultiShift_);
  msDivisiEl.addEventListener('change', muatMultiShift_);

  // BARU (22 Okt 2026, diminta Admin: "setiap modul sediakan aksi
  // Hapus") -- kolom Aksi + tombol Hapus ditambahkan ke 2 tabel ini.
  function renderMsDetail_(list) {
    const tbody = document.getElementById('msTbodyDetail');
    if (!list.length) { tbody.innerHTML = '<tr><td colspan="6"><div class="empty-state">Belum ada pola shift.</div></td></tr>'; return; }
    tbody.innerHTML = list.map(d => `
      <tr>
        <td>Shift ${d.NOMOR_SHIFT}</td>
        <td>${escapeHtml(d.JAM_MASUK)}${d.JAM_PULANG ? ' - ' + escapeHtml(d.JAM_PULANG) : ''}</td>
        <td>${d.LINTAS_TENGAH_MALAM === true || d.LINTAS_TENGAH_MALAM === 'TRUE' ? 'Ya' + (d.ATURAN_TANGGAL_ACUAN === 'HARI_BERIKUTNYA' ? ' (hadir: hari berikutnya)' : ' (hadir: hari mulai)') : '-'}</td>
        <td>${d.POLA_ROTASI === 'MINGGUAN' ? 'Bertukar/minggu' : 'Tetap'}</td>
        <td>${d.HARI_KHUSUS ? escapeHtml(d.HARI_KHUSUS) + ' (' + escapeHtml(d.JAM_MASUK_HARI_KHUSUS || '-') + ')' : '-'}</td>
        <td><button type="button" class="btn-mini ms-hapus-detail" data-id="${escapeHtml(d.ID_DETAIL)}" style="color:var(--color-danger);">Hapus</button></td>
      </tr>`).join('');
    tbody.querySelectorAll('.ms-hapus-detail').forEach(btn => {
      btn.addEventListener('click', async () => {
        if (!confirm('Hapus pola shift ini?')) return;
        try {
          await apiPost('hapusShiftDivisiDetail', { token: token(), id: btn.dataset.id });
          showSuccess('Pola shift dihapus.');
          muatMultiShift_();
        } catch (err) { showError(err.message || 'Gagal menghapus.'); }
      });
    });
  }

  function renderMsKelompok_(list) {
    const tbody = document.getElementById('msTbodyKelompok');
    if (!list.length) { tbody.innerHTML = '<tr><td colspan="5"><div class="empty-state">Belum ada relawan di-assign.</div></td></tr>'; return; }
    tbody.innerHTML = list.map(k => {
      const relawanObj = (cache.relawan || []).find(r => r.id === k.ID_RELAWAN);
      const shiftM1 = Number(k.SHIFT_MINGGU_1);
      const shiftM2 = shiftM1 === 1 ? 2 : 1;
      return `<tr>
        <td>${escapeHtml(relawanObj ? relawanObj.nama : k.ID_RELAWAN)}</td>
        <td>Kelompok ${escapeHtml(k.KELOMPOK)}</td>
        <td>Shift ${shiftM1}</td>
        <td>Shift ${shiftM2}</td>
        <td><button type="button" class="btn-mini ms-hapus-kelompok" data-id="${escapeHtml(k.ID_KELOMPOK)}" style="color:var(--color-danger);">Hapus</button></td>
      </tr>`;
    }).join('');
    tbody.querySelectorAll('.ms-hapus-kelompok').forEach(btn => {
      btn.addEventListener('click', async () => {
        if (!confirm('Keluarkan relawan ini dari kelompok?')) return;
        try {
          await apiPost('hapusKelompokRotasi', { token: token(), id: btn.dataset.id });
          showSuccess('Relawan dikeluarkan dari kelompok.');
          muatMultiShift_();
        } catch (err) { showError(err.message || 'Gagal menghapus.'); }
      });
    });
  }

  function renderMsOverride_(list) {
    const tbody = document.getElementById('msTbodyOverride');
    if (!list.length) { tbody.innerHTML = '<tr><td colspan="4"><div class="empty-state">Belum ada override.</div></td></tr>'; return; }
    tbody.innerHTML = list.map(o => `
      <tr>
        <td>${escapeHtml(o.TANGGAL_DMY)}</td>
        <td>Shift ${o.NOMOR_SHIFT}</td>
        <td>${escapeHtml(o.JAM_MASUK)}${o.JAM_PULANG ? ' - ' + escapeHtml(o.JAM_PULANG) : ''}</td>
        <td>${escapeHtml(o.KETERANGAN || '-')}</td>
      </tr>`).join('');
  }

  // Toggle tampilan field sesuai "Jenis Pola Jam Kerja" (BARU, 22 Okt
  // 2026, dokumen Pembaruan Pengaturan SIKOP §C/§G). Skema backend
  // TIDAK berubah -- 3 jenis ini cuma menentukan field mana yg
  // ditampilkan & bagaimana payload disusun saat submit.
  document.querySelectorAll('input[name="msdJenisPola"]').forEach(radio => {
    radio.addEventListener('change', () => {
      const jenis = document.querySelector('input[name="msdJenisPola"]:checked').value;
      document.getElementById('msdWrapHariBerbeda').style.display = jenis === 'HARI_BERBEDA' ? 'flex' : 'none';
      document.getElementById('msdWrapShift').style.display = jenis === 'SHIFT' ? 'flex' : 'none';
    });
  });

  // BARU (22 Okt 2026, diminta Admin) -- pilihan "Aturan Tanggal
  // Acuan" hanya relevan & tampil kalau lintas tengah malam dicentang.
  document.getElementById('msdLintasTengahMalam').addEventListener('change', (e) => {
    document.getElementById('msdWrapAturanTanggal').style.display = e.target.checked ? 'flex' : 'none';
  });

  document.getElementById('formShiftDetail').addEventListener('submit', async (e) => {
    e.preventDefault();
    if (!msDivisiEl.value) { showError('Pilih divisi dulu.'); return; }
    const jenisPola = document.querySelector('input[name="msdJenisPola"]:checked').value;

    // Susun payload sesuai jenis -- skema sheet SAMA utk ketiganya,
    // cuma nilai yg diisi berbeda (lihat dokumentasi di HTML di atas).
    let payload = {
      token: token(), namaDivisi: msDivisiEl.value,
      jamMasuk: document.getElementById('msdJamMasuk').value,
      jamPulang: document.getElementById('msdJamPulang').value,
      lintasTengahMalam: document.getElementById('msdLintasTengahMalam').checked,
      aturanTanggalAcuan: document.querySelector('input[name="msdAturanTanggal"]:checked').value
    };
    if (jenisPola === 'TETAP') {
      payload = Object.assign(payload, { nomorShift: 1, polaRotasi: 'TETAP', hariKhusus: '', jamMasukHariKhusus: '', jamPulangHariKhusus: '' });
    } else if (jenisPola === 'HARI_BERBEDA') {
      if (!document.getElementById('msdHariKhusus').value.trim()) { showError('Isi hari yang jamnya berbeda.'); return; }
      payload = Object.assign(payload, {
        nomorShift: 1, polaRotasi: 'TETAP',
        hariKhusus: document.getElementById('msdHariKhusus').value.trim().toUpperCase(),
        jamMasukHariKhusus: document.getElementById('msdJamMasukKhusus').value,
        jamPulangHariKhusus: document.getElementById('msdJamPulangKhusus').value
      });
    } else { // SHIFT
      payload = Object.assign(payload, {
        nomorShift: document.getElementById('msdNomorShift').value,
        polaRotasi: document.getElementById('msdPolaRotasi').value,
        hariKhusus: document.getElementById('msdHariKhususShift').value.trim().toUpperCase(),
        jamMasukHariKhusus: document.getElementById('msdJamMasukKhususShift').value,
        jamPulangHariKhusus: document.getElementById('msdJamPulangKhususShift').value
      });
    }

    showLoading('Menyimpan pola kerja...');
    try {
      await apiPost('simpanShiftDivisiDetail', payload);
      hideLoading();
      showSuccess('Pola kerja tersimpan.');
      document.getElementById('formShiftDetail').reset();
      document.getElementById('msdWrapHariBerbeda').style.display = 'none';
      document.getElementById('msdWrapShift').style.display = 'none';
      muatMultiShift_();
    } catch (err) {
      hideLoading();
      showError(err.message || 'Gagal menyimpan pola kerja.');
    }
  });

  document.getElementById('formKelompokRotasi').addEventListener('submit', async (e) => {
    e.preventDefault();
    if (!msDivisiEl.value) { showError('Pilih divisi dulu.'); return; }
    showLoading('Menyimpan kelompok...');
    try {
      await apiPost('simpanKelompokRotasi', {
        token: token(), namaDivisi: msDivisiEl.value,
        idRelawan: document.getElementById('krRelawan').value,
        kelompok: document.getElementById('krKelompok').value,
        shiftMinggu1: document.getElementById('krShiftMinggu1').value
      });
      hideLoading();
      showSuccess('Kelompok tersimpan.');
      document.getElementById('formKelompokRotasi').reset();
      muatMultiShift_();
    } catch (err) {
      hideLoading();
      showError(err.message || 'Gagal menyimpan kelompok.');
    }
  });

  document.getElementById('formOverrideTanggal').addEventListener('submit', async (e) => {
    e.preventDefault();
    if (!msPeriodeEl.value || !msDivisiEl.value) { showError('Pilih periode dan divisi dulu.'); return; }
    const tanggalIso = document.getElementById('ovtTanggal').value;
    if (!tanggalIso) { showError('Tanggal wajib diisi.'); return; }
    const bagian = tanggalIso.split('-');
    const tanggalDMY = bagian[2] + '/' + bagian[1] + '/' + bagian[0];
    showLoading('Menyimpan override...');
    try {
      await apiPost('simpanOverrideShiftTanggal', {
        token: token(), idPeriode: msPeriodeEl.value, namaDivisi: msDivisiEl.value,
        tanggalDMY: tanggalDMY,
        nomorShift: document.getElementById('ovtNomorShift').value,
        jamMasuk: document.getElementById('ovtJamMasuk').value,
        jamPulang: document.getElementById('ovtJamPulang').value,
        keterangan: document.getElementById('ovtKeterangan').value.trim()
      });
      hideLoading();
      showSuccess('Override tersimpan.');
      document.getElementById('formOverrideTanggal').reset();
      muatMultiShift_();
    } catch (err) {
      hideLoading();
      showError(err.message || 'Gagal menyimpan override.');
    }
  });

  // ============================================================
  // PEMERIKSAAN JADWAL (18 Okt 2026, SIKOP — sesuai wireframe §15.D
  // DIKOREKSI 18 Okt: [Valid][Peringatan][Kesalahan] + Daftar Temuan
  // lintas-divisi, bukan per-divisi spt versi sebelumnya.
  // ============================================================
  const pmrPeriodeEl = document.getElementById('pmrPeriode');
  let pmrDataTerakhir = null;

  async function muatPemeriksaan_() {
    const idPeriode = pmrPeriodeEl.value;
    const elTemuan = document.getElementById('pmrDaftarTemuan');
    if (!idPeriode) { elTemuan.innerHTML = '<p style="font-size:13px;color:var(--color-text-muted);">Pilih periode untuk melihat hasil pemeriksaan.</p>'; return; }
    elTemuan.innerHTML = '<p style="font-size:13px;color:var(--color-text-muted);">Memeriksa...</p>';
    try {
      const r = await apiPost('getRingkasanPemeriksaanPeriode', { token: token(), idPeriode });
      pmrDataTerakhir = r;
      document.getElementById('pmrValid').textContent = r.valid;
      document.getElementById('pmrPeringatan').textContent = r.peringatan;
      document.getElementById('pmrKesalahan').textContent = r.kesalahan;
      document.getElementById('pmrFilterDivisi').innerHTML = '<option value="">Semua Divisi</option>' +
        (cache.divisi || []).map(d => `<option value="${escapeHtml(d)}">${escapeHtml(d)}</option>`).join('');
      renderDaftarTemuan_();
    } catch (err) {
      elTemuan.innerHTML = `<div class="empty-state">${escapeHtml(err.message)}</div>`;
    }
  }
  pmrPeriodeEl.addEventListener('change', muatPemeriksaan_);
  // BARU (22 Okt 2026, dokumen UI/UX SIKOP): "Periksa Ulang" -- jalankan
  // ulang pemeriksaan dgn data TERBARU (bukan cache lama), sesuai §F
  // dokumen "pemeriksaan ulang harus menggunakan draf terbaru".
  // "Kembali ke Draf" -- navigasi murni ke Pembuatan Jadwal.
  document.getElementById('pmrBtnPeriksaUlang').addEventListener('click', muatPemeriksaan_);
  document.getElementById('pmrBtnKembaliDraf').addEventListener('click', () => {
    document.querySelector('[data-sub="pembuatanJadwal"]').click();
  });
  document.getElementById('pmrFilterDivisi').addEventListener('change', renderDaftarTemuan_);
  document.getElementById('pmrFilterTingkat').addEventListener('change', renderDaftarTemuan_);

  function renderDaftarTemuan_() {
    const elTemuan = document.getElementById('pmrDaftarTemuan');
    if (!pmrDataTerakhir) return;
    const filterDivisi = document.getElementById('pmrFilterDivisi').value;
    const filterTingkat = document.getElementById('pmrFilterTingkat').value;
    let temuan = pmrDataTerakhir.daftarTemuan;
    if (filterDivisi) temuan = temuan.filter(t => t.divisi === filterDivisi);
    if (filterTingkat) temuan = temuan.filter(t => t.tingkat === filterTingkat);

    if (!temuan.length) { elTemuan.innerHTML = '<div class="empty-state">✓ Tidak ada temuan yang cocok dengan filter -- jadwal bersih.</div>'; return; }

    elTemuan.innerHTML = temuan.map(t => `
      <div class="panel-block" style="margin-bottom:10px;border-left:4px solid ${t.tingkat === 'KESALAHAN' ? '#d32f2f' : '#ed6c02'};">
        <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:8px;">
          <div>
            <span class="badge ${t.tingkat === 'KESALAHAN' ? 'sakit' : 'terlambat'}" style="margin-bottom:4px;">${t.tingkat === 'KESALAHAN' ? 'Kesalahan' : 'Peringatan'}</span>
            <p style="margin:4px 0 2px;font-weight:700;">${escapeHtml(t.judul)}</p>
            <p style="margin:0;font-size:12.5px;color:var(--color-text-muted);">${escapeHtml(t.penjelasan)}</p>
            <p style="margin:4px 0 0;font-size:11px;color:var(--color-text-muted);">${escapeHtml(t.divisi)}${t.tanggal ? ' · ' + escapeHtml(t.tanggal) : ''}</p>
          </div>
          <button type="button" class="btn-mini btn-buka-jadwal-terkait" data-divisi="${escapeHtml(t.divisi)}" data-id-relawan="${escapeHtml(t.idRelawan || '')}" style="flex-shrink:0;">Buka Jadwal Terkait</button>
        </div>
      </div>`).join('');

    elTemuan.querySelectorAll('.btn-buka-jadwal-terkait').forEach(btn => {
      btn.addEventListener('click', () => {
        const tombolPanel = document.querySelector('[data-panel="panelJadwalIndividu"]');
        if (tombolPanel) tombolPanel.click();
        // Isi filter divisi di panel Koreksi Presensi kalau elemennya ada (panel lama, sudah ada sebelumnya).
        setTimeout(() => {
          const filterDivisiLama = document.getElementById('jiFilterDivisi') || document.getElementById('filterDivisiJadwalIndividu');
          if (filterDivisiLama) { filterDivisiLama.value = btn.dataset.divisi; filterDivisiLama.dispatchEvent(new Event('change')); }
        }, 300);
      });
    });
  }

  // ============================================================
  // PENETAPAN JADWAL (18 Okt 2026, SIKOP — sesuai wireframe §15.E
  // DIKOREKSI 18 Okt: tabel [Divisi|Status|Versi|Sinkronisasi] SEMUA
  // divisi sekaligus, bukan harus pilih 1 divisi dulu spt sebelumnya.
  // ============================================================
  const ptpPeriodeEl = document.getElementById('ptpPeriode');
  const LABEL_STATUS_PTP = { DRAFT: 'Draft', PERLU_PERBAIKAN: 'Perlu Perbaikan', SIAP_DITETAPKAN: 'Siap Ditetapkan', DITETAPKAN: 'Ditetapkan' };
  // Nama kelas 'sakit'/'terlambat' dipakai cuma utk WARNA (merah/oranye)
  // yg SUDAH ADA di CSS -- bukan berarti "Perlu Perbaikan" itu sakit,
  // tidak ada kelas badge merah netral terpisah saat ini.
  const BADGE_STATUS_PTP = { DRAFT: 'nonaktif', PERLU_PERBAIKAN: 'sakit', SIAP_DITETAPKAN: 'aktif', DITETAPKAN: 'aktif' };

  async function muatTabelPenetapan_() {
    const idPeriode = ptpPeriodeEl.value;
    const tbody = document.getElementById('ptpTbodyDivisi');
    document.getElementById('ptpDetail').innerHTML = '';
    if (!idPeriode) { tbody.innerHTML = '<tr><td colspan="5"><div class="empty-state">Pilih periode untuk melihat status penetapan.</div></td></tr>'; return; }
    tbody.innerHTML = '<tr><td colspan="5"><div class="empty-state">Memuat...</div></td></tr>';
    try {
      const daftar = await apiPost('getDaftarPenetapanPeriode', { token: token(), idPeriode });
      if (!daftar.length) { tbody.innerHTML = '<tr><td colspan="5"><div class="empty-state">Belum ada divisi terdaftar.</div></td></tr>'; return; }
      tbody.innerHTML = daftar.map(d => `
        <tr data-divisi="${escapeHtml(d.divisi)}">
          <td data-label="Divisi"><b>${escapeHtml(d.divisi)}</b></td>
          <td data-label="Status"><span class="badge ${BADGE_STATUS_PTP[d.status] || 'nonaktif'}">${LABEL_STATUS_PTP[d.status] || d.status}</span></td>
          <td data-label="Versi">${d.versi || '-'}</td>
          <td data-label="Sinkronisasi">${d.statusSinkronisasi === 'TERSINKRON' ? 'Tersinkron' : d.statusSinkronisasi === 'GAGAL' ? 'Gagal' : d.statusSinkronisasi === 'MENUNGGU' ? 'Menunggu' : '-'}</td>
          <td data-label="Aksi"><button type="button" class="btn-mini btn-lihat-detail-penetapan">Lihat Detail</button></td>
        </tr>`).join('');

      tbody.querySelectorAll('.btn-lihat-detail-penetapan').forEach(btn => {
        btn.addEventListener('click', () => muatDetailPenetapan_(btn.closest('tr').dataset.divisi));
      });
    } catch (err) {
      tbody.innerHTML = `<tr><td colspan="5"><div class="empty-state">${escapeHtml(err.message)}</div></td></tr>`;
    }
  }
  ptpPeriodeEl.addEventListener('change', muatTabelPenetapan_);

  async function muatDetailPenetapan_(namaDivisi) {
    const idPeriode = ptpPeriodeEl.value;
    const el = document.getElementById('ptpDetail');
    el.innerHTML = '<p style="font-size:13px;color:var(--color-text-muted);">Memuat detail...</p>';
    try {
      const s = await apiPost('getStatusPenetapanAdmin', { token: token(), idPeriode, namaDivisi });

      let html = `<div class="panel-block">
        <p class="panel-block-title">Detail Jadwal — ${escapeHtml(namaDivisi)}</p>`;

      if (s.validasi.jumlahKesalahan > 0) {
        html += `<div style="background:#fdecea;border-radius:8px;padding:10px 12px;margin-bottom:12px;">
          <p style="margin:0 0 6px;font-weight:700;color:#b3261e;">${s.validasi.jumlahKesalahan} Kesalahan menghambat penetapan</p>
          ${s.validasi.kesalahan.slice(0, 8).map(k => `<p style="margin:3px 0;font-size:12.5px;">${escapeHtml(k.penjelasan)}</p>`).join('')}
        </div>`;
      }

      html += `<div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:14px;">`;
      html += `<button type="button" class="btn-mini primary" id="ptpBtnTetapkan" ${s.validasi.valid ? '' : 'disabled'}>${s.status === 'DITETAPKAN' ? 'Tetapkan Ulang (Revisi)' : 'Tetapkan Jadwal Divisi'}</button>`;
      if (s.statusSinkronisasi === 'GAGAL') html += `<button type="button" class="btn-mini" id="ptpBtnSinkronUlang">Coba Sinkronisasi Kembali</button>`;
      html += `</div>`;

      html += `<p style="font-size:11px;font-weight:700;color:var(--color-text-muted);text-transform:uppercase;margin:0 0 6px;">Riwayat Perubahan</p><div id="ptpRiwayat"></div></div>`;
      el.innerHTML = html;

      document.getElementById('ptpBtnTetapkan').addEventListener('click', async () => {
        let alasan = '';
        if (s.status === 'DITETAPKAN') {
          alasan = prompt('Ini akan membuat versi resmi BARU (revisi). Alasan revisi:') || '';
          if (!alasan) { showError('Alasan revisi wajib diisi untuk penetapan ulang.'); return; }
        }
        if (!confirm(`Tetapkan jadwal ${namaDivisi} untuk periode ini sebagai versi resmi?`)) return;
        showLoading('Menetapkan jadwal...');
        try {
          const hasil = await apiPost('tetapkanJadwalDivisi', { token: token(), idPeriode, namaDivisi, alasanRevisi: alasan });
          hideLoading();
          showSuccess(`Jadwal ditetapkan sebagai Versi ${hasil.versi} (${hasil.jumlahBaris} baris). Sinkronisasi: ${hasil.statusSinkronisasi}.`);
          muatTabelPenetapan_();
          muatDetailPenetapan_(namaDivisi);
        } catch (err) {
          hideLoading();
          showError(err.message || 'Gagal menetapkan jadwal.');
        }
      });

      const btnSinkronUlang = document.getElementById('ptpBtnSinkronUlang');
      if (btnSinkronUlang) btnSinkronUlang.addEventListener('click', async () => {
        showLoading('Mencoba sinkronisasi ulang...');
        try {
          const hasil = await apiPost('cobaSinkronisasiUlang', { token: token(), idPeriode, namaDivisi });
          hideLoading();
          showSuccess('Status sinkronisasi: ' + hasil.statusSinkronisasi);
          muatTabelPenetapan_();
          muatDetailPenetapan_(namaDivisi);
        } catch (err) {
          hideLoading();
          showError(err.message || 'Gagal sinkronisasi ulang.');
        }
      });

      const riwayat = await apiPost('getRiwayatPenetapanDivisi', { token: token(), idPeriode, namaDivisi });
      const elRiwayat = document.getElementById('ptpRiwayat');
      if (riwayat.length) {
        elRiwayat.innerHTML = riwayat.map(r => `<p style="font-size:12px;margin:3px 0;">${new Date(r.waktu).toLocaleString('id-ID')} — ${r.aksi === 'TETAPKAN_JADWAL_DIVISI' ? 'Ditetapkan Versi ' + r.detail.versi : 'Sinkronisasi ulang'} oleh ${escapeHtml(r.pelaku)}</p>`).join('');
      } else {
        elRiwayat.innerHTML = '<p style="font-size:12px;color:var(--color-text-muted);">Belum ada riwayat.</p>';
      }
    } catch (err) {
      el.innerHTML = `<div class="empty-state">${escapeHtml(err.message)}</div>`;
    }
  }

  // ============================================================
  // PENGATURAN — Validasi Jadwal & Templat Keterangan (21 Okt 2026,
  // dokumen Pembaruan SIKOP §D.4-5)
  // ============================================================
  async function muatValidasiJadwal_() {
    const el = document.getElementById('vjDaftarAturan');
    el.innerHTML = '<p style="font-size:13px;color:var(--color-text-muted);">Memuat...</p>';
    try {
      const daftar = await apiGet('getKonfigurasiValidasiJadwal', { token: token() });
      el.innerHTML = daftar.map(v => `
        <label style="display:flex;align-items:flex-start;gap:10px;padding:10px;border:1px solid var(--color-border);border-radius:8px;margin-bottom:8px;cursor:${v.wajib ? 'default' : 'pointer'};">
          <input type="checkbox" class="vj-toggle" data-id="${escapeHtml(v.id)}" ${v.aktif ? 'checked' : ''} ${v.wajib ? 'disabled' : ''} style="width:17px;height:17px;margin-top:2px;">
          <div>
            <p style="margin:0;font-weight:600;font-size:13.5px;">${escapeHtml(v.nama)} ${v.wajib ? '<span class="badge sakit" style="font-size:9.5px;">Wajib</span>' : ''}</p>
            <p style="margin:2px 0 0;font-size:12px;color:var(--color-text-muted);">${escapeHtml(v.keterangan)}</p>
          </div>
        </label>`).join('');
      el.querySelectorAll('.vj-toggle:not(:disabled)').forEach(cb => {
        cb.addEventListener('change', async () => {
          try {
            await apiPost('simpanKonfigurasiValidasiJadwal', { token: token(), idAturan: cb.dataset.id, aktif: cb.checked });
            showSuccess('Pengaturan validasi disimpan.');
          } catch (err) { showError(err.message); cb.checked = !cb.checked; }
        });
      });
    } catch (err) {
      el.innerHTML = `<div class="empty-state">${escapeHtml(err.message)}</div>`;
    }
  }

  const LABEL_KATEGORI_TPL = { REGULER: 'Jadwal Reguler', ROTASI: 'Rotasi', SHIFT_TAMBAHAN: 'Shift Tambahan', PENUGASAN_KHUSUS: 'Penugasan Khusus' };
  async function muatTemplatKeterangan_() {
    const el = document.getElementById('tplDaftar');
    el.innerHTML = '<p style="font-size:13px;color:var(--color-text-muted);">Memuat...</p>';
    try {
      const daftar = await apiGet('getDaftarTemplatKeterangan', { token: token() });
      if (!daftar.length) { el.innerHTML = '<div class="empty-state">Belum ada templat.</div>'; return; }
      el.innerHTML = daftar.map(t => `
        <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:8px;padding:8px 10px;border:1px solid var(--color-border);border-radius:8px;margin-bottom:6px;">
          <div>
            <p style="margin:0;font-size:11px;color:var(--color-text-muted);">${LABEL_KATEGORI_TPL[t.kategori] || t.kategori}</p>
            <p style="margin:2px 0;font-weight:600;font-size:13px;">${escapeHtml(t.judul)}</p>
            <p style="margin:0;font-size:12.5px;color:var(--color-text-muted);">${escapeHtml(t.isiTeks)}</p>
          </div>
          <button type="button" class="btn-mini tpl-hapus" data-id="${escapeHtml(t.id)}" style="color:var(--color-danger);flex-shrink:0;">Hapus</button>
        </div>`).join('');
      el.querySelectorAll('.tpl-hapus').forEach(btn => {
        btn.addEventListener('click', async () => {
          if (!confirm('Hapus templat ini?')) return;
          try {
            await apiPost('hapusTemplatKeterangan', { token: token(), idTemplat: btn.dataset.id });
            muatTemplatKeterangan_();
          } catch (err) { showError(err.message); }
        });
      });
    } catch (err) {
      el.innerHTML = `<div class="empty-state">${escapeHtml(err.message)}</div>`;
    }
  }

  document.getElementById('formTemplatKeterangan').addEventListener('submit', async (e) => {
    e.preventDefault();
    const btn = e.target.querySelector('button[type=submit]');
    btn.disabled = true; btn.textContent = 'Menyimpan...';
    try {
      await apiPost('simpanTemplatKeterangan', {
        token: token(), kategori: document.getElementById('tplKategori').value,
        judul: document.getElementById('tplJudul').value.trim(), isiTeks: document.getElementById('tplIsi').value.trim()
      });
      showSuccess('Templat tersimpan.');
      e.target.reset();
      muatTemplatKeterangan_();
    } catch (err) {
      showError(err.message || 'Gagal menyimpan templat.');
    } finally {
      btn.disabled = false; btn.textContent = '+ Tambah Templat';
    }
  });

  // Muat saat sub-tab Pengaturan pertama kali dibuka (bukan langsung
  // saat load panel -- hemat panggilan kalau Admin tidak buka tab ini).
  document.querySelector('[data-sub="multiShift"]').addEventListener('click', () => {
    if (!document.getElementById('vjDaftarAturan').dataset.dimuat) {
      muatValidasiJadwal_(); muatTemplatKeterangan_();
      document.getElementById('vjDaftarAturan').dataset.dimuat = '1';
    }
    tampilkanLandingPengaturan_();
  }, { once: false });

  // Navigasi kartu landing Pengaturan (BARU, 22 Okt 2026, dokumen
  // Pembaruan Pengaturan SIKOP §G) -- "Pola Kerja" & "Kelompok" sama-
  // sama menuju seksi gabungan (keduanya butuh pilih divisi yg sama);
  // Validasi & Templat masing-masing seksi sendiri (global).
  const PETA_KARTU_KE_SEKSI = { PolaKerja: 'pengSeksiPolaKerja', Kelompok: 'pengSeksiPolaKerja', Validasi: 'pengSeksiValidasi', Templat: 'pengSeksiTemplat' };
  function tampilkanLandingPengaturan_() {
    document.getElementById('pengLanding').style.display = 'grid';
    document.getElementById('pengBtnKembali').style.display = 'none';
    Object.values(PETA_KARTU_KE_SEKSI).forEach(id => { document.getElementById(id).style.display = 'none'; });
  }
  document.querySelectorAll('.peng-kartu').forEach(btn => {
    btn.addEventListener('click', () => {
      document.getElementById('pengLanding').style.display = 'none';
      document.getElementById('pengBtnKembali').style.display = 'block';
      Object.values(PETA_KARTU_KE_SEKSI).forEach(id => { document.getElementById(id).style.display = 'none'; });
      document.getElementById(PETA_KARTU_KE_SEKSI[btn.dataset.seksi]).style.display = 'block';
    });
  });
  document.getElementById('pengBtnKembali').addEventListener('click', tampilkanLandingPengaturan_);

  // ============================================================
  // PEMBUATAN JADWAL (21 Okt 2026, dokumen Pembaruan SIKOP §E) --
  // alur terpandu: pratinjau (TANPA menulis) -> Bentuk Jadwal.
  // ============================================================
  const LABEL_STATUS_TGL = { OPERASIONAL: 'Operasional', LIBUR: 'Libur', OPERASIONAL_KHUSUS: 'Operasional Khusus' };
  let pbjDataTerakhir = null;

  function divisiTercentangPbj_() {
    return Array.from(document.querySelectorAll('.pbj-divisi-checkbox:checked')).map(cb => cb.value);
  }

  // Link "Pengaturan" dalam teks penjelasan (BARU, 22 Okt 2026) --
  // murni navigasi ke sub-tab Pengaturan, TIDAK mengubah data apa pun.
  document.querySelectorAll('.pbj-link-pengaturan').forEach(a => {
    a.addEventListener('click', (e) => { e.preventDefault(); document.querySelector('[data-sub="multiShift"]').click(); });
  });

  // Disederhanakan 22 Okt 2026 (diminta Admin): TIDAK perlu pilih
  // Periode lagi -- cukup (opsional) centang Divisi, tekan tombol.
  // Backend otomatis memproses semua tanggal operasional dari hari
  // ini dan seterusnya, lintas periode manapun.
  document.getElementById('pbjBtnPratinjau').addEventListener('click', async () => {
    const daftarDivisi = divisiTercentangPbj_(); // boleh kosong = semua divisi
    const idPeriode = document.getElementById('pbjPeriode').value; // BARU 24 Okt 2026, boleh kosong = semua periode aktif
    const elHasil = document.getElementById('pbjHasil');

    elHasil.innerHTML = '<p style="font-size:13px;color:var(--color-text-muted);">Menghitung pratinjau...</p>';
    try {
      const hasil = await apiPost('pratinjauPembuatanJadwal', { token: token(), daftarDivisi, idPeriode });
      pbjDataTerakhir = { daftarDivisi, idPeriode };
      renderPratinjauJadwal_(hasil);
    } catch (err) {
      elHasil.innerHTML = `<div class="empty-state">${escapeHtml(err.message)}</div>`;
    }
  });

  function renderPratinjauJadwal_(hasil) {
    const elHasil = document.getElementById('pbjHasil');
    let html = `
      <div class="admin-stat-grid" style="grid-template-columns:repeat(3,1fr);margin-bottom:16px;">
        <div class="admin-stat-card"><div class="admin-stat-value">${hasil.ringkasan.totalTanggal}</div><div class="admin-stat-label">Tanggal Diproses</div></div>
        <div class="admin-stat-card accent-success"><div class="admin-stat-value">${hasil.ringkasan.totalAkanDibuatBaru}</div><div class="admin-stat-label">Akan Dibuat Baru</div></div>
        <div class="admin-stat-card"><div class="admin-stat-value">${hasil.ringkasan.totalSudahTersimpanSebelumnya}</div><div class="admin-stat-label">Sudah Ada Sebelumnya</div></div>
      </div>`;

    hasil.perTanggal.forEach(h => {
      const adaYgDijadwalkan = h.perDivisi.some(p => p.dijadwalkan);
      html += `<div class="panel-block" style="margin-bottom:10px;">
        <p style="margin:0 0 8px;font-weight:700;">${escapeHtml(h.tanggal)} · ${escapeHtml(h.hari)}</p>`;
      h.perDivisi.forEach(p => {
        if (!p.dijadwalkan) {
          html += `<p style="margin:4px 0;font-size:12.5px;color:var(--color-text-muted);"><b>${escapeHtml(p.divisi)}</b>: ${escapeHtml(p.alasanDilewati)}</p>`;
        } else {
          html += `<p style="margin:8px 0 4px;font-size:12.5px;"><b>${escapeHtml(p.divisi)}</b> <span class="badge aktif" style="font-size:9.5px;">${LABEL_STATUS_TGL[p.statusTanggal]}</span> · ${p.anggota.length} anggota</p>`;
          html += '<div style="padding-left:10px;">' + p.anggota.map(a => `
            <p style="margin:2px 0;font-size:12px;color:${a.sudahAdaDiRoster ? 'var(--color-text-muted)' : 'var(--color-navy)'};">
              ${escapeHtml(a.nama)} — ${escapeHtml(a.jamMasuk)}${a.jamPulang ? ' - ' + escapeHtml(a.jamPulang) : ''}${a.lintasTengahMalam ? ' (lintas tengah malam)' : ''}${a.sudahAdaDiRoster ? ' · sudah ada' : ' · baru'}
            </p>`).join('') + '</div>';
        }
      });
      html += `</div>`;
      if (!adaYgDijadwalkan) { /* semua divisi libur tanggal ini -- blok di atas sudah menjelaskan alasannya per divisi */ }
    });

    // Disederhanakan 22 Okt 2026 (diminta Admin) -- "Bentuk Jadwal" &
    // "Perbarui Draf" DULU fungsinya identik (sama-sama idempotent,
    // cuma label beda), sekarang digabung jadi SATU tombol supaya
    // tidak membingungkan. "Bentuk Ulang" tetap terpisah krn
    // perilakunya GENUINELY beda (hapus+buat ulang baris yg belum absen).
    html += `<div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:16px;">
      <button type="button" class="btn-mini primary" id="pbjBtnTerapkan">Terapkan ke Jadwal</button>
      <button type="button" class="btn-mini" id="pbjBtnBentukUlang">Bentuk Ulang (baris belum absen saja)</button>
    </div>`;
    elHasil.innerHTML = html;

    document.getElementById('pbjBtnTerapkan').addEventListener('click', async () => {
      if (!confirm(`Terapkan Pengaturan saat ini ke jadwal? ${hasil.ringkasan.totalAkanDibuatBaru} penugasan baru akan dibuat. Baris yang sudah ada tidak akan ditimpa.`)) return;
      showLoading('Menerapkan jadwal...');
      try {
        // Diperbaiki 23 Okt 2026 (dilaporkan Admin: "Server tidak
        // merespons" saat tekan tombol ini). SEBAB: timeout default
        // apiPost cuma 20 detik, padahal aksi ini bisa memproses SEMUA
        // tanggal operasional lintas periode (lihat SikopPembuatanJadwal.gs
        // bentukJadwal) -- utk data produksi dgn beberapa periode aktif +
        // banyak divisi, ini wajar makan >20 detik. Timeout dinaikkan ke
        // 2 menit + pesan kustom yg tidak menakutkan (proses backend TETAP
        // bisa saja sudah berhasil meski frontend menyerah duluan --
        // Admin disarankan cek dgn Pratinjau sebelum mengulang, bukan
        // langsung asumsi gagal total).
        const r = await apiPost('bentukJadwal', { token: token(), daftarDivisi: pbjDataTerakhir.daftarDivisi, idPeriode: pbjDataTerakhir.idPeriode }, 120000,
          'Proses masih berjalan di server (jadwal lintas periode bisa makan waktu). Jangan tekan tombol lagi -- tunggu sebentar lalu tekan "Pratinjau" utk cek apakah sudah selesai.');
        hideLoading();
        let pesan = `Jadwal diperbarui: ${r.totalDibuat} baris baru, ${r.totalSudahAda} sudah ada sebelumnya.`;
        if (r.totalDilewatiResmi) pesan += ` (${r.totalDilewatiResmi} tanggal dilewati krn divisinya sudah Ditetapkan resmi.)`;
        showSuccess(pesan);
        document.getElementById('pbjBtnPratinjau').click();
      } catch (err) { hideLoading(); showError(err.message || 'Gagal menerapkan jadwal.'); }
    });

    document.getElementById('pbjBtnBentukUlang').addEventListener('click', async () => {
      if (!confirm('Bentuk ULANG jadwal? Baris yang BELUM pernah absen akan dihapus dan dibuat ulang dengan Pengaturan terbaru. Baris yang SUDAH ada aktivitas absensi TIDAK akan disentuh.')) return;
      showLoading('Membentuk ulang jadwal...');
      try {
        // Diperbaiki 23 Okt 2026 -- SAMA PERSIS alasannya dgn tombol
        // "Terapkan" di atas, lihat catatan lengkap di situ.
        const r = await apiPost('bentukUlangJadwal', { token: token(), daftarDivisi: pbjDataTerakhir.daftarDivisi, idPeriode: pbjDataTerakhir.idPeriode }, 120000,
          'Proses masih berjalan di server (jadwal lintas periode bisa makan waktu). Jangan tekan tombol lagi -- tunggu sebentar lalu tekan "Pratinjau" utk cek apakah sudah selesai.');
        hideLoading();
        showSuccess(`Jadwal dibentuk ulang: ${r.totalDihapus} baris lama dihapus, ${r.totalDibuat} baris baru dibuat.`);
        document.getElementById('pbjBtnPratinjau').click();
      } catch (err) { hideLoading(); showError(err.message || 'Gagal membentuk ulang jadwal.'); }
    });
  }
})();
