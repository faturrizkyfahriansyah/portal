# SPPG Jeungjing — Repository Aplikasi

Repository ini berisi tiga proyek yang tetap terpisah:

1. `01-PORTAL`
2. `02-SIPENDOK`
3. `03-SIPOGIM`

Masing-masing proyek memisahkan frontend dan backend Google Apps Script. Database Google Spreadsheet tidak disertakan di repository ini.

Baca `00-DOKUMENTASI/ARSITEKTUR-REPOSITORY-FULL.md` sebelum melakukan perubahan atau deployment.
